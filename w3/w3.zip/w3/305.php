<?php
for ($i = 1; $i <= 5; $i = $i + 1){
    print "$i <br />\n";
}
?>