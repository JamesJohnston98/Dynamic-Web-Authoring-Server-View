<?php
for($i = 1; $i <= 21; $i = $i + 2){
    print "$i <br />\n";
}



?>