<?php
$destination = "Mexico";

switch ($destination){
    case "Mexico":
    print "Remember to pack sun cream";
    break;
        
    case "Iceland":
     print "Remember to pack a wooly jumper";
     break;
                
    default:
        print "Stay at home";
}

?>