<?php 
$destination = "Mexico";
if ($destination == "Iceland") {
    print "Remember to pack a wooly jumper";
}
elseif($destination == "Mexico") {
    print "Remember to pack sun cream";
}
else print "Stay at home"; //default result
?>