<?php

for($i = 1; $i <= 5; $i = $i + 1) {
   
    $square = $i * $i;
    print "the square number is $square <br />\n";
}


?>