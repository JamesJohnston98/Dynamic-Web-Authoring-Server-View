<?php
$i = 1; 
while ($i <= 21){
    
    print "$i <br />";  
    $i = $i + 2;
}
?>