<?php
$i = 10;
while ($i >=1){
 print "$i <br />";  
    $i = $i - 1;
}
?>