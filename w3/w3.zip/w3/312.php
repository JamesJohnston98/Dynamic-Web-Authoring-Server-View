<?php
$count = 0;   // initialise as 0
for ($i = 0; $i<10; $i=$i+1){
$count = $count + 1;  
}
print "Total number is: $count";   

?>