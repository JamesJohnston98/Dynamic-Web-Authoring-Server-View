<?php
for($i = 10; $i >=1; $i = $i -1){
    print "$i<br />\n";
}
?>