<?php
$i = 1;
while ($i <= 5){
    

$square = $i * $i;
print "$square <br />"; 
$i = $i + 1;
    
}
?>