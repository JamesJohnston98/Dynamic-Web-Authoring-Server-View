<?php

function positive($a)
{
$a +2;
$a >= 0;
}

$i = positive(10);
print "$i";
?>