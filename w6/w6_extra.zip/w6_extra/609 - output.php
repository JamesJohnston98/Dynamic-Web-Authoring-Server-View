<?php
$i = 0;
echo $i++;
?>