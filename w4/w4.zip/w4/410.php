<?php

$start_n = 1;
$end_n = 10;



$sum = 0;


for($i = $start_n; $i <= $end_n; $i++){
 $sum += $i;
}
print "$sum"

?>