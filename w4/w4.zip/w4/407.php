<?php
$i = 0;
echo $i++;
$i = 0;
echo ++$i;
?>