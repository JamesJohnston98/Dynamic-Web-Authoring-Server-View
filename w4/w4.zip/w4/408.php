<?php
$i = 0;
while($i<5){
print ("*");
$i = $i + 1;
}


?>