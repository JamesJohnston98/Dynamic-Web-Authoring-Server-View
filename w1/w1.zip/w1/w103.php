<?php
 print "A simple intial script";
?>