<?php
print "Hello World!";
?>