<?php
$age = 6;
print "Brian is $age years old.";
?>