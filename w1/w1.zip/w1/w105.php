<?php
$days = 3;
$newdays = 100;
$days = $newdays;

print "$days"; 
print "$newdays";


?>