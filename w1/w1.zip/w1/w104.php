<?php
/*
A script that gets information about the 
PHP version being used.
*/
phpinfo();
?>