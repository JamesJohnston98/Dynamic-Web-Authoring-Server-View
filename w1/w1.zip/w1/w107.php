<?php
$first_num = 12;
$second_num = 356;
$temp = $first_num;
$first_num = $second_num;
$second_num = $temp;
print "first_num = $first_num <br /> 
second_num = $second_num";
?>