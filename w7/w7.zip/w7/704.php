<?php
$comments = "Good Job";
$len = strlen($comments);
print "Length = $len";
?>