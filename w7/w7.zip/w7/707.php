<?php
$inquote = "Now is the Time";
$lower = strtolower($inquote);
$upper = strtoupper($inquote);
print("upper = $upper lower = $lower");


?>