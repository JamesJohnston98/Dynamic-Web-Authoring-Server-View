<?php
$in_name= " Joe Jackson ";
$name = trim($in_name);
print "name = $name$name";
?>


