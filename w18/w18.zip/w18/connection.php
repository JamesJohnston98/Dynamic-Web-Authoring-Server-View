<?php
$con = mysqli_connect("localhost","B00730860", 'eWgxKPE2') or die("unable to connect!");
mysqli_select_db($con, "B00730860");
?>