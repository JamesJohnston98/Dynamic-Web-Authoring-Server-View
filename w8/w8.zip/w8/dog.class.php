<?php
class dog {
public $name;
public function bark() {
echo 'woof';
}
}
?>