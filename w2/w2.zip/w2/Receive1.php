<?php
$email=$_POST["email"];
print "<br><br><font size =5>Your Email Address is $email</font>"
?>