<?php
$name = "Ian Young";
$firstname = substr($name, 0, 3);
$secondname = substr($name, 4, 5);
print "firstname is $firstname and secondname is $secondname";
?>