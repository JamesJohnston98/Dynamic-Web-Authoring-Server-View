<?php
$apples = 34;
$oranges = 14;
$total_fruit = $apples + $oranges;
print "The total number of fruit is $total_fruit";
?>