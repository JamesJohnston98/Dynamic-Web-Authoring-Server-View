<?php
$inquote = "Now Is The Time";
$lower = strtolower($inquote);
$upper = strtoupper($inquote);
print ("upper = $upper lower = $lower");

?>